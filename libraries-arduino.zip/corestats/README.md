## Core Analog Statistics

A support library for analog time series analysis.

Code mostly borrowed from [Plaquette by Sofian Audrey](https://github.com/SofaPirate/Plaquette).

